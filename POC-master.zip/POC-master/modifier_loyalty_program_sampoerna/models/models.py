# -*- coding: utf-8 -*-
from datetime import date, datetime, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning

class LoyaltyProgram(models.Model):
    
    _inherit = 'loyalty.program'

    scheduler = fields.Boolean('Assign loyalty points on schedule')
    schedule_day_assign = fields.Integer('Assign Points Period (days)')
    schedule_loyalty_points_amount = fields.Float('Loyalty points to assign')
    assigned_categ_ids = fields.Many2many('pos.category', string='Assigned Categories')

    @api.onchange('scheduler')
    def onchange_scheduler(self):
        self.schedule_day_assign = ''
        self.schedule_loyalty_points_amount = ''
        
    @api.multi
    def _check_customer_loyalty_program(self):
        """
        Check customers 
        """
        for program in self.search([('scheduler','=',True)]):
            customers = self.env['res.partner'].search([
                    ('customer','=', True),
                    ('reward_applicable','=', True), 
                    ('loyalty_id','!=', False), 
                    ('mem_join_date','!=', False)
                ])
            for customer in customers:
                match_date = datetime.strptime(customer.mem_join_date, '%Y-%m-%d') + timedelta(days=program.schedule_day_assign)
                if (date.today() == match_date.date()):
                    customer_points = customer.loyalty_points + program.schedule_loyalty_points_amount
                    customer.write({'loyalty_points':customer_points})


    @api.multi
    def generate_category_rewards(self):
        if not self.assigned_categ_ids:
            raise Warning(_('No Assigned Categories selected.'))

        self.reward_ids.unlink()

        for category in self.assigned_categ_ids:
            category_products = self.env['product.product'].search([('categ_id','=', category.id)])
            for product in category_products:
                reward_vals = {
                    'loyalty_program_id':self.id,
                    'name': product.display_name,
                    'reward_type': 'gift',
                    'minimum_points': product.lst_price,
                    'point_cost': product.lst_price,
                    'gift_product_id': product.id,
                }
                self.env['loyalty.reward'].create(reward_vals)


    @api.multi
    def clear_category_rewards(self):
        self.reward_ids.unlink()


class Partner(models.Model):

    _inherit = 'res.partner'

    rfid_code = fields.Char('RFID Code')