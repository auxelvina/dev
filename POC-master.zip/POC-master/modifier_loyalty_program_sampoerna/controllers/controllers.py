# -*- coding: utf-8 -*-
from odoo import http

# class ModifierLoyaltyProgramSampoerna(http.Controller):
#     @http.route('/modifier_loyalty_program_sampoerna/modifier_loyalty_program_sampoerna/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/modifier_loyalty_program_sampoerna/modifier_loyalty_program_sampoerna/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('modifier_loyalty_program_sampoerna.listing', {
#             'root': '/modifier_loyalty_program_sampoerna/modifier_loyalty_program_sampoerna',
#             'objects': http.request.env['modifier_loyalty_program_sampoerna.modifier_loyalty_program_sampoerna'].search([]),
#         })

#     @http.route('/modifier_loyalty_program_sampoerna/modifier_loyalty_program_sampoerna/objects/<model("modifier_loyalty_program_sampoerna.modifier_loyalty_program_sampoerna"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('modifier_loyalty_program_sampoerna.object', {
#             'object': obj
#         })