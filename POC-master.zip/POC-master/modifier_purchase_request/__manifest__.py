{
    "name": "Modifier Purchase request",
    "category": 'Purchase',
    'summary': '',
    "description": """

    """,
    "author": "Hashmicro/Shiyas",
    "website": "http://hashmicro.com/",
    "depends": ['base', 'purchase'],
    "data": [
        'view/purchase_order.xml'

    ],
    "installable": True,
    "application": True,
    "auto_install": False,
}