from odoo import fields, models


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    estimated_procurement_value = fields.Selection(
        [('small', 'Small value purchase (<$3,000)'), ('quotation', 'Quotation ($3,001 - 70,000)'),
         ('tender', 'Tender (Above $70,000)')], string='Estimated Procurement Value')


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    recommend = fields.Selection([('yes','Yes'),('no','No')], String='Recommend ?')



