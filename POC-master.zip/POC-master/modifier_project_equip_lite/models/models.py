# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Tasks(models.Model):

	_inherit = 'project.task'

	project_id = fields.Many2one('project.project', string="Kanban Board")


class AccountAnalytic(models.Model):

	_inherit = 'account.analytic.line'

	project_id = fields.Many2one('project.project', string="Kanban Board")
	
