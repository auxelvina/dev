# -*- coding: utf-8 -*-

from odoo import models, fields, api


class TheoreticalCountLine(models.Model):
    
    _name = 'mrp.theoretical.count.line'

    @api.depends('sn', 'pb', 'cu', 'ag', 'ni', 'p', 'ge', 'fe', 'sb', 'bi', 'zn', 'al', 'a_s', 'cd')
    def _compute_material_rate(self):
        for line in self:
            total_material_rate = 0

            for attr in ['sn', 'pb', 'cu', 'ag', 'ni', 'p', 'ge', 'fe', 'sb', 'bi', 'zn', 'al', 'a_s', 'cd']:
                total_material_rate += getattr(line, attr)
            
            line.update({
                    'total_material_rate':total_material_rate
                })

    @api.depends('unit_price', 'qty')
    def _compute_subtotal(self):
        for line in self:
            sub_totalprice = line.qty * line.unit_price
            line.update({
                    'sub_totalprice':sub_totalprice
                })


    material_name = fields.Char(string="Material Name", required=True)
    qty = fields.Float(string="Qty (kg)", required=True, digits=(16,2))
    unit_price = fields.Float(string="Price", required=True, digits=(16,2))
    sub_totalprice = fields.Float(string="Sub Total", compute="_compute_subtotal", digits=(16,2))
    sn = fields.Float(string="Sn", default=0, digits=(16,4))
    pb = fields.Float(string="Pb", default=0, digits=(16,4))
    cu = fields.Float(string="Cu", default=0, digits=(16,4))
    ag = fields.Float(string="Ag", default=0, digits=(16,4))
    ni = fields.Float(string="Ni", default=0, digits=(16,4))
    p = fields.Float(string="P", default=0, digits=(16,4))
    ge = fields.Float(string="Ge", default=0, digits=(16,4))
    fe = fields.Float(string="Fe", default=0, digits=(16,4))
    sb = fields.Float(string="Sb", default=0, digits=(16,4))
    bi = fields.Float(string="Bi", default=0, digits=(16,4))
    zn = fields.Float(string="Zn", default=0, digits=(16,4))
    al = fields.Float(string="Al", default=0, digits=(16,4))
    a_s = fields.Float(string="As", default=0, digits=(16,4))
    cd = fields.Float( string="Cd", default=0, digits=(16,4))
    total_material_rate = fields.Float(string="Total Material Rate",  compute="_compute_material_rate", digits=(16,4))
    theoretical_count_id = fields.Many2one('mrp.theoretical.count',string='Theoretical Count Reference', required=True, ondelete='cascade', index=True, copy=False)

class TheoreticalCount(models.Model):

    _name = 'mrp.theoretical.count'
    _rec_name = 'ref'

    
    @api.depends('theory_count_line.sub_totalprice', 'theory_count_line.unit_price', 'theory_count_line.sn', 'theory_count_line.pb', 'theory_count_line.cu', 'theory_count_line.ag', 'theory_count_line.ni', 'theory_count_line.p', 'theory_count_line.ge', 'theory_count_line.fe', 'theory_count_line.sb', 'theory_count_line.bi', 'theory_count_line.zn', 'theory_count_line.al', 'theory_count_line.a_s', 'theory_count_line.cd', 'theory_count_line.qty')
    def _compute_total(self):
        for theoretical in self:
            sn_total = pb_total = cu_total = ag_total = ni_total = p_total = ge_total = fe_total = sb_total = bi_total = zn_total = al_total = a_s_total = cd_total = qty_total = unit_price_total = price_total = 0
            for line in theoretical.theory_count_line:
                qty_total += line.qty 
                unit_price_total += line.unit_price
                price_total += line.sub_totalprice
                sn_total += (line.sn * line.qty)
                pb_total += (line.pb * line.qty)
                cu_total += (line.cu * line.qty)
                ag_total += (line.ag * line.qty)
                ni_total += (line.ni * line.qty)
                p_total += (line.p * line.qty)
                ge_total += (line.ge * line.qty)
                fe_total += (line.fe * line.qty)
                sb_total += (line.sb * line.qty)
                bi_total += (line.bi * line.qty)
                zn_total += (line.zn * line.qty)
                al_total += (line.al * line.qty)
                a_s_total += (line.a_s * line.qty)
                cd_total += (line.cd * line.qty)
            sn_total = sn_total/qty_total
            pb_total = pb_total/qty_total
            cu_total = cu_total/qty_total
            ag_total = ag_total/qty_total
            ni_total = ni_total/qty_total
            p_total = p_total/qty_total
            ge_total = ge_total/qty_total
            fe_total = fe_total/qty_total
            sb_total = sb_total/qty_total
            bi_total = bi_total/qty_total
            zn_total = zn_total/qty_total
            al_total = al_total/qty_total
            a_s_total = a_s_total/qty_total
            cd_total = cd_total/qty_total

            theoretical.update({
                    'sn_total':sn_total,
                    'pb_total':pb_total,
                    'cu_total':cu_total,
                    'ag_total':ag_total,
                    'ni_total':ni_total,
                    'p_total':p_total,
                    'ge_total':ge_total,
                    'fe_total':fe_total,
                    'sb_total':sb_total,
                    'bi_total':bi_total,
                    'zn_total':zn_total,
                    'al_total':al_total,
                    'a_s_total':a_s_total,
                    'cd_total':cd_total,
                    'qty_total':qty_total,
                    'unit_price_total':unit_price_total,
                    'price_total':price_total,
                })

    @api.depends('unit_price_total','exchange_usd1', 'exchange_usd2')
    def _compute_unit_price_total(self):
        for theoretical in self:
           if theoretical.exchange_usd1 != 0:
                unitprice_total_usd1 = theoretical.unit_price_total / theoretical.exchange_usd1
                theoretical.update({
                    'unitprice_total_usd1':unitprice_total_usd1
                })
           if theoretical.exchange_usd2 != 0:
                unitprice_total_usd2 = theoretical.unit_price_total / theoretical.exchange_usd2
                theoretical.update({
                    'unitprice_total_usd2':unitprice_total_usd2,
                })

    @api.depends('theory_count_line.sub_totalprice')
    def _compute_price_total(self):
        for theoretical in self:
            price_total = 0
            for line in theoretical.theory_count_line:
                price_total += line.sub_totalprice
            theoretical.update({
                    'price_total':price_total
                })

    ref = fields.Char('Theoretical Count ID', required=True)
    exchange_usd1 = fields.Float('Exchange Rate USD 1', default=0, required=True, digits=(16,2))
    exchange_usd2 = fields.Float(string='Exchange Rate USD 2', default=0, digits=(16,2))
    unitprice_total_usd1 = fields.Float(string='Unit Price', default=0, required=True, compute="_compute_unit_price_total", digits=(16,2))
    unitprice_total_usd2 = fields.Float(string='Unit Price', default=0, compute="_compute_unit_price_total", digits=(16,2))
    sn_total = fields.Float(string='Total Sn', compute="_compute_total", digits=(16,4))
    pb_total = fields.Float(string='Total Pb', compute="_compute_total", digits=(16,4))
    cu_total = fields.Float(string='Total Cu', compute="_compute_total", digits=(16,4))
    ag_total = fields.Float(string='Total Ag', compute="_compute_total", digits=(16,4))
    ni_total = fields.Float(string='Total Ni', compute="_compute_total", digits=(16,4))
    p_total = fields.Float(string='Total P', compute="_compute_total", digits=(16,4))
    ge_total = fields.Float(string='Total Ge', compute="_compute_total", digits=(16,4))
    fe_total = fields.Float(string='Total Fe', compute="_compute_total", digits=(16,4))
    sb_total = fields.Float(string='Total Sb', compute="_compute_total", digits=(16,4))
    bi_total = fields.Float(string='Total Bi', compute="_compute_total", digits=(16,4))
    zn_total = fields.Float(string='Total Zn', compute="_compute_total", digits=(16,4))
    al_total = fields.Float(string='Total Al', compute="_compute_total", digits=(16,4))
    a_s_total = fields.Float(string='Total As', compute="_compute_total", digits=(16,4))
    cd_total = fields.Float(string='Total Cd', compute="_compute_total", digits=(16,4))
    qty_total = fields.Float(string='Qty Total', compute="_compute_total", digits=(16,2))
    unit_price_total = fields.Float(string='Unit Price Total', compute="_compute_total", digits=(16,2))
    price_total = fields.Float('Price Total', compute="_compute_price_total", digits=(16,2))
    theory_count_line = fields.One2many('mrp.theoretical.count.line', 'theoretical_count_id', 'Theoretical Count Lines', copy=True)

