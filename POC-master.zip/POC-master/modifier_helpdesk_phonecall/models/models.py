# -*- coding: utf-8 -*-

from odoo import models, fields, api

class LoggedCalls(models.Model):

    _inherit = 'crm.phonecall'

    ticket_id = fields.Many2one('helpdesk.ticket', 'Tickets')



class HelpdeskTicket(models.Model):

    _inherit = 'helpdesk.ticket'


    @api.multi
    def _compute_phone_count(self):
        for ticket in self:
            call_count = self.env['crm.phonecall'].search_count([('ticket_id','=',ticket.id)])
            ticket.update({
                    'call_count':call_count,
                })

    call_count = fields.Integer('Logged Calls', compute="_compute_phone_count")

    @api.multi
    def action_helpdesk_ticket_open_calls_tree_view(self):
        return {
            'name': 'Phone Calls',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'crm.phonecall',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('ticket_id', 'in', self.ids)],
        }

