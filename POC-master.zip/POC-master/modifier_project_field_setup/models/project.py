# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models,fields

class Project(models.Model):
    _inherit = 'project.task'
    project_id = fields.Many2one(required=True)