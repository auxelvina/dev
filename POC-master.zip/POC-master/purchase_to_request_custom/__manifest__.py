# -*- coding: utf-8 -*-
{
    "name": "Purchase to Request Custom Access Rights",
    "author": "Janbaz aga(janbazaga444@gmail.com)",
    "version": "10.0.1.0",
    "website": "www.hashmicro.com",
    "category": "Purchase Management",
    "depends": [
        "purchase_request", "account_analytic_parent",
    ],
    "data": [
        # "security/ir.model.access.csv",
        "views/analytic_account_view_inherit.xml",
    ],
    "installable": True,
    "auto_install": False,
    "application": True,
}
