# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime
from odoo.exceptions import UserError
import logging
_logger = logging.getLogger(__name__)


class AccountAnalyticAccountInherit(models.Model):
    _inherit = "account.analytic.account"

    allow_over_budget = fields.Boolean("Allow Over Budget")
