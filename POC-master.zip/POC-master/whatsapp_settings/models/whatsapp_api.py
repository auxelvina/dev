from odoo import models, fields, api, _
from odoo.exceptions import UserError
import json
import requests
from odoo.http import request
import urllib2


class WhatsappBlast(models.Model):
    _name = 'whatsapp.blast'

    name = fields.Many2one('mail.message.settings', string='From', required=True)
    partner_ids = fields.One2many('res.partner', 'whatsapp_id', 'Recipients')
    content = fields.Text('Content')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('fail', 'Failed'),
    ], string='Status', index=True, readonly=True, default='draft')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.user.company_id)

    @api.multi
    def action_sent_message(self):
        if self.company_id:
            success = False
            for partner in self.partner_ids:
                apikey = self.name.key_token
                number = partner.whatsapp_no
                msg = self.content
                # url = """https://eu2.chat-api.com/instance85533/sendMessage?token=tuq5iry3avoip2n3""" + str(apikey) + """&number=""" + str(number) + """&text=""" + str(msg) + """"""
                # url = """https://panel.apiwha.com/send_message.php?apikey=""" + str(apikey) + """&number=""" + str(number) + """&text=""" + str(msg) + """"""
                # r = requests.get(url=url)
                # data = r.json()
                # if data.get('success') == False:
                #     self.write({'state': 'fail'})
                # else:
                #     self.write({'state': 'sent'})
                data = {'phone': number, 'body': msg}
                req = urllib2.Request(apikey)
                req.add_header('Content-Type', 'application/json')
                response = urllib2.urlopen(req, json.dumps(data))
                if response.getcode() == 200:
                    self.write({'state': 'sent'})
                else:
                    self.write({'state': 'fail'})


class ResCompany(models.Model):
    _inherit = 'res.company'

    api_key = fields.Char('Whatsapp API Key')


class WhatsappBlast(models.Model):
    _inherit = 'res.partner'

    whatsapp_id = fields.Many2one('whatsapp.blast', 'Whatsapp')
    whatsapp_no = fields.Char('Whatsapp Number')
