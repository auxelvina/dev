# -*- coding: utf-8 -*-
{
    'name': 'whatsapp_settings',
    'version': '10.0',
    'category': 'Message',
    'summary': 'whatsapp_settings',
    'description': "whatsapp_settings",
    'author': 'waqas',
    'depends': ['mail','base','sms_whatsapp_api_config'],
    'data': [
        'security/ir.model.access.csv',
        'views/whatsapp_blast_view.xml',
        'views/whatsapp_config_view.xml'
    ],
    'installable': True,
    'auto_install': False,
}